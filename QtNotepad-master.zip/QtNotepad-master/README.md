# QtNotepad
![GitHub Releases](https://img.shields.io/github/downloads/rattle99/QtNotepad/v1.0/total.svg)

<p align="center">
  <img width="609" height="315" src="https://media.giphy.com/media/2YpNAnXlE2tmcZmmDo/giphy.gif">
</p>

___

This is a an effort to try and use Qt5 the c++ gui toolkit. The notepad app is about *50KB* in size and is a standalone [executable](https://github.com/rattle99/QtNotepad/releases) with basic functionalities such as opening, saving, printing and creating new files.
